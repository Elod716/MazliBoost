﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;

namespace MazliBoost
{
    public partial class MainWindow : Window
    {
        // =========================================================
        // GAME DETECTION
        // =========================================================

        private int detectedGamePid = -1;
        private string detectedGameName = "No game detected";
        private string detectedProcessName = "";

        // Known game process names.
        // This lets MázliBoost recognize games without asking
        // the user for an EXE name.
        private readonly Dictionary<string, string> knownGames =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "GTA5", "Grand Theft Auto V" },
                { "GTA5Enhanced", "Grand Theft Auto V Enhanced" },
                { "RDR2", "Red Dead Redemption 2" },
                { "WorldOfTanks", "World of Tanks" },
                { "WorldOfTanksCE", "World of Tanks" },
                { "LeagueClient", "League of Legends" },
                { "FortniteClient-Win64-Shipping", "Fortnite" },
                { "VALORANT-Win64-Shipping", "VALORANT" },
                { "cs2", "Counter-Strike 2" },
                { "eldenring", "Elden Ring" },
                { "RocketLeague", "Rocket League" },
                { "Overwatch", "Overwatch" },
                { "OverwatchTest", "Overwatch" },
                { "FallGuys_client_game", "Fall Guys" },
                { "RobloxPlayerBeta", "Roblox" },
                { "Terraria", "Terraria" },
                { "Stardew Valley", "Stardew Valley" },
                { "HogwartsLegacy", "Hogwarts Legacy" },
                { "Cyberpunk2077", "Cyberpunk 2077" },
                { "witcher3", "The Witcher 3" },
                { "PAYDAY3Client-Win64-Shipping", "PAYDAY 3" },
                { "BeamNG.drive", "BeamNG.drive" },
                { "FactoryGame", "Satisfactory" }
            };

        // =========================================================
        // WINDOWS API
        // =========================================================

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(
            IntPtr hWnd,
            out uint processId);

        [DllImport("psapi.dll")]
        private static extern bool EmptyWorkingSet(
            IntPtr hProcess);

        [DllImport("kernel32.dll")]
        private static extern IntPtr OpenProcess(
            uint dwDesiredAccess,
            bool bInheritHandle,
            uint dwProcessId);

        [DllImport("kernel32.dll")]
        private static extern bool CloseHandle(
            IntPtr hObject);

        private const uint PROCESS_QUERY_INFORMATION = 0x0400;
        private const uint PROCESS_SET_QUOTA = 0x0100;

        // =========================================================
        // CONSTRUCTOR
        // =========================================================

        public MainWindow()
        {
            InitializeComponent();

            LoadSystemInfo();

            // Don't immediately assume the foreground window
            // is a game. Scan the entire process list instead.
            DetectGame();
        }

        // =========================================================
        // GAME DETECTION
        // =========================================================

        private void DetectGame()
        {
            detectedGamePid = -1;
            detectedGameName = "No game detected";
            detectedProcessName = "";

            StatusText.Text = "Status: Detecting game...";

            try
            {
                Process[] processes = Process.GetProcesses();

                // -------------------------------------------------
                // STEP 1:
                // Check known game executables first.
                // -------------------------------------------------

                foreach (Process process in processes)
                {
                    try
                    {
                        if (process.Id == Environment.ProcessId)
                            continue;

                        string processName = process.ProcessName;

                        if (knownGames.TryGetValue(
                                processName,
                                out string gameName))
                        {
                            detectedGamePid = process.Id;
                            detectedProcessName = processName;
                            detectedGameName = gameName;

                            process.Dispose();

                            UpdateGameUI();

                            return;
                        }
                    }
                    catch
                    {
                        // Process may disappear while scanning.
                    }
                    finally
                    {
                        try
                        {
                            process.Dispose();
                        }
                        catch
                        {
                        }
                    }
                }

                // -------------------------------------------------
                // STEP 2:
                // Special detection for Minecraft / Java.
                // -------------------------------------------------

                Process[] javaProcesses =
                    Process.GetProcessesByName("javaw");

                foreach (Process javaProcess in javaProcesses)
                {
                    try
                    {
                        if (IsMinecraftJavaProcess(javaProcess.Id))
                        {
                            detectedGamePid = javaProcess.Id;
                            detectedProcessName = "javaw";
                            detectedGameName = "Minecraft";

                            javaProcess.Dispose();

                            UpdateGameUI();

                            return;
                        }
                    }
                    catch
                    {
                    }
                    finally
                    {
                        try
                        {
                            javaProcess.Dispose();
                        }
                        catch
                        {
                        }
                    }
                }

                // -------------------------------------------------
                // STEP 3:
                // Look for visible windows that strongly resemble
                // games.
                // -------------------------------------------------

                foreach (Process process in processes)
                {
                    try
                    {
                        if (process.Id == Environment.ProcessId)
                            continue;

                        if (process.MainWindowHandle == IntPtr.Zero)
                            continue;

                        string title =
                            process.MainWindowTitle?.Trim() ?? "";

                        string name =
                            process.ProcessName?.Trim() ?? "";

                        if (string.IsNullOrWhiteSpace(title))
                            continue;

                        if (IsIgnoredProcess(name, title))
                            continue;

                        if (LooksLikeGameWindow(name, title))
                        {
                            detectedGamePid = process.Id;
                            detectedProcessName = name;
                            detectedGameName = title;

                            process.Dispose();

                            UpdateGameUI();

                            return;
                        }
                    }
                    catch
                    {
                    }
                    finally
                    {
                        try
                        {
                            process.Dispose();
                        }
                        catch
                        {
                        }
                    }
                }
            }
            catch
            {
                // Detection failure should never crash the optimizer.
            }

            UpdateGameUI();
        }

        // =========================================================
        // MINECRAFT DETECTION
        // =========================================================

        private bool IsMinecraftJavaProcess(int pid)
        {
            try
            {
                using ManagementObjectSearcher searcher =
                    new ManagementObjectSearcher(
                        $"SELECT CommandLine FROM Win32_Process WHERE ProcessId = {pid}");

                foreach (ManagementObject obj in searcher.Get())
                {
                    string commandLine =
                        obj["CommandLine"]?.ToString() ?? "";

                    string lower =
                        commandLine.ToLowerInvariant();

                    // Minecraft Java instances normally contain
                    // one or more of these markers.
                    if (lower.Contains("minecraft"))
                        return true;

                    if (lower.Contains("net.fabricmc.loader"))
                        return true;

                    if (lower.Contains("fabric-loader"))
                        return true;

                    if (lower.Contains("lwjgl"))
                        return true;

                    if (lower.Contains("quilt-loader"))
                        return true;

                    if (lower.Contains("forge"))
                        return true;
                }
            }
            catch
            {
                // WMI can fail without administrator privileges.
            }

            // If WMI doesn't work, check the window title.
            try
            {
                using Process process =
                    Process.GetProcessById(pid);

                string title =
                    process.MainWindowTitle?.ToLowerInvariant() ?? "";

                if (title.Contains("minecraft"))
                    return true;
            }
            catch
            {
            }

            return false;
        }

        // =========================================================
        // GAME WINDOW HEURISTICS
        // =========================================================

        private bool LooksLikeGameWindow(
            string processName,
            string windowTitle)
        {
            string p = processName.ToLowerInvariant();
            string t = windowTitle.ToLowerInvariant();

            string[] gameKeywords =
            {
                "minecraft",
                "grand theft auto",
                "gta v",
                "red dead redemption",
                "world of tanks",
                "counter-strike",
                "valorant",
                "fortnite",
                "elden ring",
                "rocket league",
                "overwatch",
                "roblox",
                "terraria",
                "stardew valley",
                "hogwarts legacy",
                "cyberpunk",
                "the witcher",
                "beamng",
                "satisfactory",
                "fall guys"
            };

            foreach (string keyword in gameKeywords)
            {
                if (t.Contains(keyword))
                    return true;
            }

            return false;
        }

        // =========================================================
        // IGNORED WINDOWS PROCESSES
        // =========================================================

        private bool IsIgnoredProcess(
            string processName,
            string windowTitle)
        {
            string p = processName.ToLowerInvariant();
            string t = windowTitle.ToLowerInvariant();

            string[] ignored =
            {
                "explorer",
                "dwm",
                "searchhost",
                "searchapp",
                "sihost",
                "taskmgr",
                "devenv",
                "powershell",
                "pwsh",
                "cmd",
                "conhost",
                "applicationframehost",
                "textinputhost",
                "runtimebroker",
                "ctfmon",
                "startmenuexperiencehost",
                "lockapp",
                "systemsettings",
                "msedge",
                "chrome",
                "firefox",
                "brave",
                "opera",
                "discord",
                "steam",
                "steamwebhelper",
                "epicgameslauncher",
                "battle.net",
                "riotclientservices",
                "riotclientux",
                "eadesktop",
                "ubisoftconnect"
            };

            foreach (string item in ignored)
            {
                if (p == item)
                    return true;
            }

            string[] ignoredTitles =
            {
                "settings",
                "task manager",
                "file explorer",
                "visual studio",
                "microsoft edge",
                "google chrome",
                "mozilla firefox",
                "discord",
                "steam",
                "epic games launcher"
            };

            foreach (string item in ignoredTitles)
            {
                if (t.Contains(item))
                    return true;
            }

            return false;
        }

        // =========================================================
        // GAME UI
        // =========================================================

        private void UpdateGameUI()
        {
            if (detectedGamePid > 0)
            {
                GameNameText.Text = detectedGameName;

                GameStatusText.Text =
                    $"{detectedProcessName}.exe • PID {detectedGamePid}";

                StatusText.Text =
                    "Status: Game detected ✓";
            }
            else
            {
                GameNameText.Text =
                    "No game detected";

                GameStatusText.Text =
                    "Start a game and click Detect Again.";

                StatusText.Text =
                    "Status: Ready";
            }
        }

        private void DetectButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            DetectGame();
        }

        // =========================================================
        // SYSTEM INFORMATION
        // =========================================================

        private void LoadSystemInfo()
        {
            try
            {
                CpuText.Text = GetCpuName();
            }
            catch
            {
                CpuText.Text = "Unknown CPU";
            }

            try
            {
                RamText.Text = $"{GetRamGB():0.0} GB";
            }
            catch
            {
                RamText.Text = "Unknown";
            }

            try
            {
                PowerText.Text = GetPowerPlan();
            }
            catch
            {
                PowerText.Text = "Unknown";
            }
        }

        private string GetCpuName()
        {
            using ManagementObjectSearcher searcher =
                new ManagementObjectSearcher(
                    "SELECT Name FROM Win32_Processor");

            foreach (ManagementObject obj in searcher.Get())
            {
                string name =
                    obj["Name"]?.ToString()?.Trim();

                if (!string.IsNullOrWhiteSpace(name))
                    return name;
            }

            return "Unknown CPU";
        }

        private double GetRamGB()
        {
            using ManagementObjectSearcher searcher =
                new ManagementObjectSearcher(
                    "SELECT TotalVisibleMemorySize FROM Win32_OperatingSystem");

            foreach (ManagementObject obj in searcher.Get())
            {
                double kb =
                    Convert.ToDouble(
                        obj["TotalVisibleMemorySize"]);

                return kb / 1024.0 / 1024.0;
            }

            return 0;
        }

        // =========================================================
        // POWER PLAN
        // =========================================================

        private string GetPowerPlan()
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = "powercfg.exe",
                    Arguments = "/getactivescheme",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true
                };

                using Process process =
                    Process.Start(psi)!;

                string output =
                    process.StandardOutput.ReadToEnd();

                process.WaitForExit();

                int start =
                    output.IndexOf("(");

                int end =
                    output.IndexOf(")", start + 1);

                if (start >= 0 && end > start)
                {
                    return output.Substring(
                        start + 1,
                        end - start - 1);
                }

                return "Active";
            }
            catch
            {
                return "Unknown";
            }
        }

        // =========================================================
        // BOOST
        // =========================================================

        private void BoostButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            BoostButton.IsEnabled = false;

            StatusText.Text =
                "Status: Optimizing system...";

            try
            {
                // -------------------------------------------------
                // 1. High Performance power plan
                // -------------------------------------------------

                SetHighPerformance();

                // -------------------------------------------------
                // 2. Windows Game Mode
                // -------------------------------------------------

                EnableGameMode();

                // -------------------------------------------------
                // 3. Disable Game DVR capture
                // -------------------------------------------------

                DisableGameCapture();

                // -------------------------------------------------
                // 4. Optimize detected game priority
                // -------------------------------------------------

                if (detectedGamePid > 0)
                {
                    SetGamePriority(
                        detectedGamePid);
                }

                // -------------------------------------------------
                // 5. Light background memory cleanup
                // -------------------------------------------------

                CleanBackgroundMemory();

                // -------------------------------------------------
                // DONE
                // -------------------------------------------------

                StatusText.Text =
                    "Status: BOOST ACTIVE 🚀";

                LoadSystemInfo();

                string game =
                    detectedGamePid > 0
                        ? detectedGameName
                        : "No game detected";

                MessageBox.Show(
                    "MázliBoost optimization completed!\n\n" +
                    "✓ High Performance power plan\n" +
                    "✓ Windows Game Mode\n" +
                    "✓ Game capture optimization\n" +
                    "✓ Background memory cleanup\n" +
                    (detectedGamePid > 0
                        ? "✓ Game process optimized\n\n"
                        : "\n") +
                    $"Detected game:\n{game}",
                    "MázliBoost",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                StatusText.Text =
                    "Status: Some optimizations failed";

                MessageBox.Show(
                    "MázliBoost encountered a problem:\n\n" +
                    ex.Message,
                    "MázliBoost",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
            finally
            {
                BoostButton.IsEnabled = true;
            }
        }

        // =========================================================
        // HIGH PERFORMANCE
        // =========================================================

        private void SetHighPerformance()
        {
            ProcessStartInfo psi = new ProcessStartInfo
            {
                FileName = "powercfg.exe",
                Arguments = "/setactive SCHEME_MIN",
                UseShellExecute = true,
                Verb = "runas",
                CreateNoWindow = true
            };

            using Process process =
                Process.Start(psi)!;

            process.WaitForExit();

            if (process.ExitCode != 0)
            {
                throw new Exception(
                    "Could not enable the High Performance power plan.");
            }
        }

        // =========================================================
        // GAME PRIORITY
        // =========================================================

        private void SetGamePriority(int pid)
        {
            try
            {
                using Process process =
                    Process.GetProcessById(pid);

                // AboveNormal is intentional.
                // "High" can starve Windows/background threads.
                process.PriorityClass =
                    ProcessPriorityClass.AboveNormal;
            }
            catch
            {
                // Game may have closed or may be protected.
            }
        }

        // =========================================================
        // WINDOWS GAME MODE
        // =========================================================

        private void EnableGameMode()
        {
            try
            {
                using RegistryKey key =
                    Registry.CurrentUser.CreateSubKey(
                        @"Software\Microsoft\GameBar");

                key?.SetValue(
                    "AutoGameModeEnabled",
                    1,
                    RegistryValueKind.DWord);
            }
            catch
            {
                // User registry access can fail.
            }
        }

        // =========================================================
        // GAME DVR
        // =========================================================

        private void DisableGameCapture()
        {
            try
            {
                using RegistryKey key =
                    Registry.CurrentUser.CreateSubKey(
                        @"Software\Microsoft\Windows\CurrentVersion\GameDVR");

                key?.SetValue(
                    "AppCaptureEnabled",
                    0,
                    RegistryValueKind.DWord);
            }
            catch
            {
            }

            try
            {
                using RegistryKey key =
                    Registry.CurrentUser.CreateSubKey(
                        @"System\GameConfigStore");

                key?.SetValue(
                    "GameDVR_Enabled",
                    0,
                    RegistryValueKind.DWord);
            }
            catch
            {
            }
        }

        // =========================================================
        // LIGHT MEMORY CLEANUP
        // =========================================================

        private void CleanBackgroundMemory()
        {
            try
            {
                Process[] processes =
                    Process.GetProcesses();

                foreach (Process process in processes)
                {
                    try
                    {
                        if (process.Id == Environment.ProcessId)
                            continue;

                        if (process.Id == detectedGamePid)
                            continue;

                        if (process.MainWindowHandle != IntPtr.Zero)
                            continue;

                        string name =
                            process.ProcessName
                            ?.ToLowerInvariant() ?? "";

                        if (IsProtectedProcess(name))
                            continue;

                        IntPtr handle = OpenProcess(
                            PROCESS_QUERY_INFORMATION |
                            PROCESS_SET_QUOTA,
                            false,
                            (uint)process.Id);

                        if (handle != IntPtr.Zero)
                        {
                            EmptyWorkingSet(handle);
                            CloseHandle(handle);
                        }
                    }
                    catch
                    {
                        // Individual processes may reject access.
                    }
                    finally
                    {
                        try
                        {
                            process.Dispose();
                        }
                        catch
                        {
                        }
                    }
                }
            }
            catch
            {
            }
        }

        // =========================================================
        // PROTECTED PROCESSES
        // =========================================================

        private bool IsProtectedProcess(string name)
        {
            string[] protectedNames =
            {
                "system",
                "idle",
                "registry",
                "smss",
                "csrss",
                "wininit",
                "winlogon",
                "services",
                "lsass",
                "svchost",
                "dwm",
                "memory compression",
                "securityhealthservice",
                "msmpeng",
                "antimalware service executable"
            };

            foreach (string protectedName in protectedNames)
            {
                if (name == protectedName)
                    return true;
            }

            return false;
        }
    }
}